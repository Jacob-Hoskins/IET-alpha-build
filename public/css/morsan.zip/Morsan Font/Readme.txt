Hello,

By installing or using this font, you are agree to the Product Usage Agreement:
- This demo font is ONLY for PERSONAL USE. NO COMMERCIAL USE ALLOWED!

- Please isit this link, if you need a commercial license as below:
https://typebae.gumroad.com/l/morsan

- Webfont Extended License
- Logo License
- Extended License (includes: E-book/Digital Publishin, Digital Ads For Social Media Commercial, End Product For Commercial: Prints/Sales/Pcs/Static digital images.
- App/Game License
- Server License
- Broadcast License
- Corporate License

Marketplace
Creative Market: https://crmrkt.com/klvlrm
Myfonts: https://www.myfonts.com/collections/morsan-font-typebae

Please send a short message with your question
typebaecreative@gmail.com

Greetings,
Typebae Foundry